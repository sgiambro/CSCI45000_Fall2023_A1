1) make clean

2) make

3) kill any running rmiregistry (kill -9 <pid>)

4) make setup

5) make runServer (in-csci-rrpc01.cs.iupui.edu)

6) make runClient (in-csci-rrpc02.cs.iupui.edu)